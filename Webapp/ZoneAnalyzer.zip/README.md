
  # ZoneAnalyzer

  This is a code bundle for ZoneAnalyzer. The original project is available at https://www.figma.com/design/0Q3jcv4SxzXrC11dqdFQcS/ZoneAnalyzer.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  